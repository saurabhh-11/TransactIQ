from fastapi import FastAPI, File, UploadFile, Depends, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
import shutil
import os
import logging
from pathlib import Path
from sqlalchemy.orm import Session
from backend.preprocess import extract_transactions
from backend.ocr import extract_text
import backend.models as models
import backend.crud as crud
from backend.database import SessionLocal, engine
from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List

os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

# Ensure database tables exist
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# ✅ CORS Middleware to allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Allow requests from Next.js frontend
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

# ✅ Logging setup (Fixed)
logging.basicConfig(
    level=logging.INFO, 
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]  # Ensures logs appear in the console
)
logger = logging.getLogger(__name__)

# Upload directory
UPLOAD_DIR = Path("backend/uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Pydantic models
class StatementSchema(BaseModel):
    user_id: int
    statement_period_start: datetime
    statement_period_end: datetime
    issued_date: datetime
    file_path: str

class TransactionSchema(BaseModel):
    statement_id: int
    user_id: int
    transaction_date: datetime
    description: str
    merchant_name: str
    amount: float
    transaction_type: str
    balance_after_transaction: Optional[float] = None
    category: Optional[str] = None

# Dependency to get database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def home():
    return {"message": "TransactIQ API is running!"}

@app.post("/upload/")
async def upload_pdf(
    file: UploadFile = File(...),
    user_id: int = Form(...),  
    db: Session = Depends(get_db)
):
    try:
        # Validate file type
        if not file.filename.endswith(".pdf"):
            raise HTTPException(status_code=400, detail="Only PDF files are allowed.")

        # Save uploaded PDF
        file_path = UPLOAD_DIR / file.filename
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        logger.info(f"✅ File saved at: {file_path}")

        # Extract text via OCR
        extracted_text = extract_text(str(file_path))
        logger.info(f"✅ Extracted Text:\n{extracted_text}")

        # Extract transactions with NLP Categorization
        structured_data = extract_transactions(extracted_text)
        logger.info(f"✅ Categorized Transactions: {structured_data}")

        if not structured_data:
            raise HTTPException(status_code=400, detail="No transactions found in the statement.")

        # ✅ Save statement under the provided `user_id`
        statement_data = {
            "user_id": user_id,  
            "statement_period_start": datetime(2025, 1, 1),
            "statement_period_end": datetime(2025, 1, 31),
            "issued_date": datetime.utcnow(),
            "file_path": str(file_path)
        }
        statement = crud.create_statement(db, statement_data)

        if not statement:
            raise HTTPException(status_code=500, detail="Failed to store statement.")

        # ✅ Store transactions under the same `user_id`
        inserted_transactions = []
        for transaction in structured_data:
            transaction["statement_id"] = statement.id  
            transaction["user_id"] = user_id  
            transaction.setdefault("category", "Uncategorized")  # ✅ Ensure category exists
            
            stored_transaction = crud.create_transaction(db, transaction)
            if stored_transaction:
                inserted_transactions.append(stored_transaction)

        return {
            "message": "Transactions stored successfully!",
            "total_inserted": len(inserted_transactions),
            "statement_id": statement.id  # Returning statement_id for frontend
        }
    except Exception as e:
        logger.error(f"❌ Error processing file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

@app.get("/transactions/{statement_id}", response_model=List[TransactionSchema])
def get_transactions(statement_id: int, db: Session = Depends(get_db)):
    """
    Fetch transactions for a specific statement.
    """
    transactions = crud.get_transactions_by_statement_id(db, statement_id)

    if not transactions:
        logger.warning(f"⚠️ No transactions found for statement ID {statement_id}")
        raise HTTPException(status_code=404, detail="No transactions found for this statement.")

    logger.info(f"✅ Transactions fetched: {transactions}")
    return transactions
