import logging
from sqlalchemy.orm import Session
from backend import models
from backend.preprocess import CATEGORIES, categorize_transaction  

# ✅ Setup Logging
logging.basicConfig(
    level=logging.INFO, 
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# ✅ Create Statement
def create_statement(db: Session, statement_data: dict):
    try:
        statement = models.Statement(**statement_data)
        db.add(statement)
        db.commit()
        db.refresh(statement)
        logger.info(f"✅ Statement ID {statement.id} created for User {statement.user_id}")
        return statement
    except Exception as e:
        db.rollback()
        logger.error(f"❌ Error creating statement: {str(e)}")
        return None

# ✅ Assign Correct Category using BERT Model
def get_category(description: str):
    """Uses the BERT model to classify transaction descriptions."""
    return categorize_transaction(description)  # ✅ Call the BERT model function


# ✅ Create Transaction (with proper category assignment)
def create_transaction(db: Session, transaction_data: dict):
    try:
        description = transaction_data.get("description", "").strip()
        transaction_data["category"] = get_category(description)  # ✅ Assign correct category

        transaction = models.Transaction(**transaction_data)
        db.add(transaction)
        db.commit()
        db.refresh(transaction)
        logger.info(f"✅ Transaction {transaction.id} stored under Statement {transaction.statement_id}")
        return transaction
    except Exception as e:
        db.rollback()
        logger.error(f"❌ Error storing transaction: {str(e)}")
        return None

# ✅ Fetch Transactions by Statement ID (Filtered by User ID)
def get_transactions_by_statement_id(db: Session, statement_id: int, user_id: int):
    transactions = (
        db.query(models.Transaction)
        .join(models.Statement, models.Transaction.statement_id == models.Statement.id)
        .filter(models.Transaction.statement_id == statement_id, models.Statement.user_id == user_id)
        .all()
    )
    
    if not transactions:
        logger.warning(f"⚠️ No transactions found for Statement ID {statement_id} (User ID {user_id})")
    else:
        logger.info(f"✅ Retrieved {len(transactions)} transactions for Statement ID {statement_id} (User ID {user_id})")
    
    return transactions
